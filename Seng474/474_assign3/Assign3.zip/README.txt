
Instructions for running code for send 474 assignment 3:

I have written all of my experiments in Jupiter notebooks and all of the code I wrote can be found in the code.zip file. This code zip file also contain the two dataset csv files that I used as my datasets.

Explanation of the code:

Data input cell is at the top and is used for all the experiments.


I have all four parts below that are split into different cells and labelled, with the title of what model/method I am trying to demonstrating.
