
Instructions for running code for send 474 assignment 1:

I have written all of my experiments in Jupiter notebooks and all of the code I wrote can be found in the code.zip file. This code zip file also contain the txt files that I used as my datasets.

Explanation of the code:

I have decision tree, random forest and neural networks python functions in their own cell that I passed parameters through in order to run the experiments. 

Below the functions I have two cells called Data Set 1 and Data Set 2 with the cells for all of the experiments listed below. If you want to run the experiments with dataset 1 run that cell and then the experiment you would like to run. If you would like to run the experiments with dataset 2, run that cell and then the experiment you would like to run.

All of the experiments are listed as DT (for Decision Tree), RF (for Random Forest) or NN( for Neural Network}