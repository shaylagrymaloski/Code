
Instructions for running code for send 474 assignment 1:

I have written all of my experiments in Jupiter notebooks and all of the code I wrote can be found in the code.zip file. This code zip file also contain the txt files that I used as my datasets.

Explanation of the code:

Data input cell is at the top and is used for all the experiments.

I have methods to run log regression and svm labelled at the top as well as helper methods for k-fold cross validation. In their own cell I passed parameters through in order to run the experiments. 

I have all four parts below that are split into different cells and labelled.

